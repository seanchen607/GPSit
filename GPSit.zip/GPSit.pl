#!/usr/bin/perl -w

=head1 Name

  GPSit.pl

=head1 Description

  This script was designed to do Guided Phylogenetic Search in tree (GPSit).

  Please note:

    Imported protein sequences of new species and initial MSAs should be all in FASTA format, with ".fa" or ".fasta" as suffixes.

=head1 Version

  Author: Xiao Chen, seanchen607@gmail.com

  Version: 1.0	Date: 2017/09/12

=head1 Environment

  Environment settings before usage (please use practical paths of MUSCLE/MrBayes/BUCKy/BLASTP in the command lines below):
  
    echo 'PATH=$PATH:{path_to_MUSCLE}:{path_to_MrBayes}:{path_to_BUCKy}:{path_to_BLASTP}' >> ~/.bashrc
    echo 'LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH' >> ~/.bashrc
    echo 'PKG_CONFIG_PATH=/usr/local/lib/pkgconfig:$PKG_CONFIG_PATH' >> ~/.bashrc
    source ~/.bashrc

=head1 Usage

  perl  GPStree.pl  [options]  -i <input_dir1_initial_MSAs>  -n <input_dir2_new_proteins>  -o <output_dir>  -b <BMGE_dir>

  Options:

	-i <input_dir1_initial_MSAs>: [required] path to directory containing initial MSAs of original species (in FASTA format);
	
	-n <input_dir2_new_proteins>: [required] path to directory containing protein data files of newly sequenced species (in FASTA format);
	
	-o <output_dir>: [required] path to output directory;
	
	-b <BMGE_dir>: [required] path to program "BMGE.jar" (BMGE v1.12);
	
	-e <evalue_cutoff>: [optional] cutoff value of Evalue for BLASTP, default is 1e-10;
	
	-d <ident_cutoff>: [optional] cutoff value of identity for BLASTP, default is 50;

    -S: [optional] using stringent masking (gap rate cut-off = 30%, similarity matrix = BLOSUM62), instead of relaxed masking (default, gap rate cut-off = 50%, similarity matrix = BLOSUM30), when calling BMGE;

    -M: [optional] jump to masking step (incompatible with option "-T");

    -T: [optional] jump to tree-building step (incompatible with option "-M");

    -U: [optional] call BUCKy to proceed Bayesian Concordance Analysis (BCA);

    -l <taxa_list>: [optional, but required when "-U" is on] genes do not have all taxa in this specified list will be shipped in BCA analysis;

    -g <generation_number>: [optional] integer, automatically enabled if "-U" is on, default is 100000;

    -f <sample_frequency>: [optional] integer, automatically enabled if "-U" is on, default is 100;

    -t <threads_numbr>: [optional] integer, default is 1.
	
=head1 Example

  perl  GPStree.pl  -i ./01_initial_MSAs/  -n ./02_new_protein_seqs/  -o ./03_output_dir/  -b /public/home/weibo2/CX/soft/BMGE-1.12/  -e 1e-10  -d 50  -g 100000  -f 100  -t 16

=cut

use warnings;
use Getopt::Std;
use POSIX qw(strftime);
getopts("i:n:o:b:e:d:g:f:t:l:MSTU");
unless ((defined $opt_i) && (defined $opt_n) && (defined $opt_o) && (defined $opt_b) && (!$opt_M || !$opt_T)) {
	die `pod2text $0`;
}
$SIG{INT} = \&int_handler;
$opt_i =~ s/\/$//;
$opt_n =~ s/\/$//;
$opt_o =~ s/\/$//;
$opt_b =~ s/\/$//;
my $evalue_cutoff = "1e-10";
$evalue_cutoff = $opt_e if (defined $opt_e);
my $ident_cutoff = 50;
$ident_cutoff = int($opt_d) if (defined $opt_d);
my $generation = 100000;
$generation = int($opt_g) if (defined $opt_g);
my $freq = 100;
$freq = int($opt_f) if (defined $opt_f);
my $cpu = 1;
$cpu = int($opt_t) if (defined $opt_t);
my $input_dir = $opt_i . "/";
my $new_prot_dir = $opt_n . "/";
my $output_dir = $opt_o . "/";
my $BMGE_dir = $opt_b . "/";
my $log_dir = $output_dir . "00_log/";
my $clean_input_dir = $output_dir . "01_clean_guide_prot/";
my $clean_new_prot_dir = $output_dir . "02_clean_new_prot/";
my $sh_dir = $output_dir . "03_sh/";
my $blast_dir = $output_dir . "04_blast/";
my $unaligned_dir = $output_dir . "05_unaligned/";
my $aligned_dir = $output_dir . "06_update_MSAs/";
my $masked_dir;
if ($opt_S) {
	$masked_dir = $output_dir . "06_update_MSAs/masked_MSA_stringent/";
} else {
	$masked_dir = $output_dir . "06_update_MSAs/masked_MSA_relax/";
}
my $concatenate_dir = $output_dir . "06_update_MSAs/concatenated_MSA/";
my $BItree_aligned_dir = $masked_dir . "BItree_g${generation}_f${freq}/";
my $BItree_concatenate_dir = $concatenate_dir . "BItree_g${generation}_f${freq}/";
########################################################################
my $datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
mkdir $output_dir or print "\n[$datestring] Directory exists: $output_dir\n";
mkdir $new_prot_dir or print "\n[$datestring] Directory exists: $new_prot_dir\n";
mkdir $input_dir or print "\n[$datestring] Directory exists: $input_dir\n";
mkdir $clean_new_prot_dir or print "\n[$datestring] Directory exists: $clean_new_prot_dir\n";
mkdir $clean_input_dir or print "\n[$datestring] Directory exists: $clean_input_dir\n";
mkdir $sh_dir or print "\n[$datestring] Directory exists: $sh_dir\n";
open (SH1, ">$sh_dir" . "01_blast.sh") or die "can not open: $!";
open (SH2, ">$sh_dir" . "02_align.sh") or die "can not open: $!";
open (SH3, ">$sh_dir" . "03_BItree.sh") or die "can not open: $!";
mkdir $blast_dir or print "\n[$datestring] Directory exists: $blast_dir\n";
mkdir $unaligned_dir or print "\n[$datestring] Directory exists: $unaligned_dir\n";
mkdir $aligned_dir or print "\n[$datestring] Directory exists: $aligned_dir\n";
mkdir $masked_dir or print "\n[$datestring] Directory exists: $masked_dir\n";
mkdir $concatenate_dir or print "\n[$datestring] Directory exists: $concatenate_dir\n";
mkdir $BItree_aligned_dir or print "\n[$datestring] Directory exists: $BItree_aligned_dir\n";
mkdir $BItree_concatenate_dir or print "\n[$datestring] Directory exists: $BItree_concatenate_dir\n";
########################################################################
mkdir $log_dir or print STDERR "\n[$datestring] Directory exists: $log_dir\n";
open (STDOUT, ">$log_dir" . "GPStree.log") or die "can not open: $!";
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n##########################################\n##########################################\n[$datestring] Job start...\n##########################################\n##########################################\n";
print STDERR "\n##########################################\n##########################################\n[$datestring] Job start...\n##########################################\n##########################################\n";
########################################################################
########################################################################
main: {
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Preparing update MSAs...\n";
print STDERR "\n[$datestring] Preparing update MSAs...\n";
opendir NEWPROT_DIR, $new_prot_dir or die "can not open: $!";
my @new_prots = grep /(\.fa$|\.fasta$)/i, readdir NEWPROT_DIR;
my @new_prots_sort = sort {$a cmp $b} @new_prots;
close NEWPROT_DIR;
#########################
my @update_species;
foreach my $new_prot (@new_prots_sort) {
	my $update_species=$new_prot;
	$update_species=~s/\.fa.+//;
	push @update_species, $update_species;
}
#########################
foreach my $new_prot (@new_prots_sort) {           ########### Remove none AA chararcters from new protein seqs ###########
	my $fileExist = -e "${clean_new_prot_dir}${new_prot}";
	next if $fileExist;
	open (IN, "<$new_prot_dir" . $new_prot);
	open (OUT, ">$clean_new_prot_dir" . $new_prot);
	my $flag = 0;
	while (<IN>) {
		$_ =~ s/[^A-Z]//gi unless /\>/;
		$_ =~ s/\s//g unless /\>/;
		$_ = "\n" . $_ if (/\>/ && $flag);
		$_ .= "\n" if (eof);
		$_ =~ s/\r\n/\n/;
		$_ =~ s/\t/ /g;
		print OUT $_;
		$flag = 1;
	}
	close IN;
	close OUT;
}
########################################################################
opendir INPUT_DIR, $input_dir or die "can not open: $!";
my @inputs = grep /(\.fa$|\.fasta$)/i, readdir INPUT_DIR;
my @inputs_sort = sort {$a cmp $b} @inputs;
close INPUT_DIR;
#########################
my @initial_species;
my %flag_input_species;
foreach my $input (@inputs_sort) {           ########### Remove none AA chararcters from initial MSAs ###########
	open (IN, "<$input_dir" . $input);
	while (<IN>) {
		if (/\>(.+?)[\r\n]/){
			push @initial_species, $1 unless $flag_input_species{$1};
			$flag_input_species{$1} = 1;
		}
	}	
	my $fileExist = -e "${clean_input_dir}$input";
	next if $fileExist;
	open (IN, "<$input_dir" . $input);
	open (OUT, ">$clean_input_dir" . $input);
	my $flag = 0;
	while (<IN>) {
		$_ =~ s/[^A-Z]//gi unless /\>/;
		$_ =~ s/\s//g unless /\>/;
		$_ = "\n" . $_ if (/\>/ && $flag);
		$_ .= "\n" if (eof);
		$_ =~ s/\r\n/\n/;
		print OUT $_;
		$flag = 1;
	}
	close IN;
	close OUT;
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] BLAST new protein sequences to sequences in initial MSAs (BLASTP)...\n";
print STDERR "\n[$datestring] BLAST new protein sequences to sequences in initial MSAs (BLASTP)...\n";
print "\n[$datestring] Makeblastdb of protein sequences of new species...\n";
print STDERR "\n[$datestring] Makeblastdb of protein sequences of new species...\n";
opendir NEWPROT_CLEAN_DIR, $clean_new_prot_dir or die "can not open: $!";
my @clean_new_prots = grep /(\.fa$|\.fasta$)/i, readdir NEWPROT_CLEAN_DIR;
my @clean_new_prots_sort = sort {$a cmp $b} @clean_new_prots;
close NEWPROT_CLEAN_DIR;
############ Show Progress ############
my $total = @clean_new_prots;
my $count = 0;
my $percent2 = 0;
#######################################
my $thread_id=1;
if (!$opt_T && !$opt_M) {
	foreach my $clean_new_prot (@clean_new_prots_sort) {           ########### Makeblastdb of new protein seqs ###########
		&show_progress($count,$total,$percent2);
		my $cmd = "makeblastdb -in ${clean_new_prot_dir}$clean_new_prot  -dbtype prot  -parse_seqids -out ${clean_new_prot_dir}$clean_new_prot";
		my $modulus = $thread_id % $cpu;
		$cmd .= " &" if ($modulus && $thread_id < $total-1);    ########## enable multi-threads ###########
		$thread_id++;
		eval {&blast_sh($cmd)};
		my $fileExist = -e "${clean_new_prot_dir}$clean_new_prot.psq";
		next if $fileExist;
		sleep (1);
		eval {&process_cmd($cmd)};
	}
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Makeblastdb of protein sequences of initial MSAs...\n";
print STDERR "\n[$datestring] Makeblastdb of protein sequences of initial MSAs...\n";
opendir INPUT_CLEAN_DIR, $clean_input_dir or die "can not open: $!";
my @clean_inputs = grep /(\.fa$|\.fasta$)/i, readdir INPUT_CLEAN_DIR;
my @clean_inputs_sort = sort {$a cmp $b} @clean_inputs;
close INPUT_CLEAN_DIR;
############ Show Progress ############
$total =  @clean_inputs;
$count = 0;
$percent2 = 0;
#######################################
$thread_id=1;
if (!$opt_T && !$opt_M) {
	foreach my $clean_input (@clean_inputs_sort) {           ########### Makeblastdb of initial MSAs ###########
		&show_progress($count,$total,$percent2);
		my $cmd = "makeblastdb -in ${clean_input_dir}$clean_input  -dbtype prot  -parse_seqids -out ${clean_input_dir}$clean_input";
		my $modulus = $thread_id % $cpu;
		$cmd .= " &" if ($modulus && $thread_id < $total-1);    ########## enable multi-threads ###########
		$thread_id++;
		eval {&blast_sh($cmd)};
		my $fileExist = -e "${clean_input_dir}$clean_input.psq";
		next if $fileExist;
		sleep (1);
		eval {&process_cmd($cmd)};
	}
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Blasting...\n";
print STDERR "\n[$datestring] Blasting...\n";
############ Show Progress ############
$total = @clean_new_prots_sort * @clean_inputs_sort * 2;
$count = 0;
$percent2 = 0;
#######################################
$thread_id=1;
if (!$opt_T && !$opt_M) {
	print "\n[$datestring] Forward blasting...\n";
	print STDERR "\n[$datestring] Forward blasting...\n";
	foreach my $query (@clean_new_prots_sort) {           ########### BLAST new protein seqs to initial MSAs ###########
		foreach my $subject (@clean_inputs_sort) {
			&show_progress($count,$total,$percent2);
			my $query_id=$query;
			my $subject_id=$subject;
			$query_id=~s/\.fa.+//;
			$subject_id=~s/\.fa.+//;
			my $cmd = "blastp -db  ${clean_input_dir}$subject -query ${clean_new_prot_dir}$query -out ${blast_dir}${query_id}__${subject_id}.tab  -evalue 1e-5  -outfmt  6  -max_target_seqs  1  -num_threads 1";
			my $modulus = $thread_id % $cpu;
			$cmd .= " &" if ($modulus && ($thread_id < $total-1));    ########## enable multi-threads ###########
			$thread_id++;
			eval {&blast_sh($cmd)};
			my $fileExist = -e "${blast_dir}${query_id}__${subject_id}.tab";
			next if $fileExist;
			sleep (3);
			eval {&process_cmd($cmd)};
		}
	}
	print "\n[$datestring] Backward blasting...\n";
	print STDERR "\n[$datestring] Backward blasting...\n";
	foreach my $subject (@clean_new_prots_sort) {           ########### BLAST initial MSAs to new protein seqs ###########
		foreach my $query (@clean_inputs_sort) {
			&show_progress($count,$total,$percent2);
			my $query_id=$query;
			my $subject_id=$subject;
			$query_id=~s/\.fa.+//;
			$subject_id=~s/\.fa.+//;
			my $cmd = "blastp -db  ${clean_new_prot_dir}$subject -query ${clean_input_dir}$query -out ${blast_dir}${query_id}__${subject_id}.tab  -evalue 1e-5  -outfmt  6  -max_target_seqs  1  -num_threads 1";
			my $modulus = $thread_id % $cpu;
			$cmd .= " &" if ($modulus && ($thread_id < $total-1));    ########## enable multi-threads ###########
			$thread_id++;
			eval {&blast_sh($cmd)};
			my $fileExist = -e "${blast_dir}${query_id}__${subject_id}.tab";
			next if $fileExist;
			sleep (3);
			eval {&process_cmd($cmd)};
		}
	}
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Loading new protein sequences...\n";
print STDERR "\n[$datestring] Loading new protein sequences...\n";
foreach my $clean_new_prot (@clean_new_prots_sort) {          ########### read in new protein sequences ############
	open (IN, "<$clean_new_prot_dir" . $clean_new_prot);
	my $name="";
	my $last_name="";
	my $seq="";
	$clean_new_prot=~s/\.fa.+//;
	while (<IN>) {
		if (/\>(.+?)\s/) {
			$name=$1;
			${$clean_new_prot}{$last_name}=$seq if $last_name;
			$last_name=$name;
			$seq="";
		} else {
			chomp $_;
			$seq.=$_;
		}
		${$clean_new_prot}{$name}=$seq if (eof);
	}
	close IN;
}
###########
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Writing best-hit protein sequence (with least E-value) to initial MSAs...\n";
print STDERR "\n[$datestring] Writing best-hit protein sequence (with least E-value) to initial MSAs...\n";
opendir INPUT_DIR, $input_dir or die "can not open: $!";
my @list = grep /\.csv$/i, readdir INPUT_DIR;
close INPUT_DIR;
my $flag_list = 0;
if ($list[0]) {
	open (LIST, "<${input_dir}" . $list[0]);
	$flag_list = 1;
} else {
	print STDERR "\nInitial MSAs information list not found: $!\n";
}
my $flag_new_species = 0;
open (NEWLIST, ">${output_dir}" . "Update_MSAs_info.csv") or die "can not open: $!";
my $list_num = 0;
my %oldlist;
if ($flag_list) {
	while (<LIST>) {           ########### Read in initial MSAs information list ###########
		$_ =~ s/[\t\r\n]//g;
		$oldlist{$list_num} = $_;
		$list_num++;
	}
}
close LIST;
$list_num = 0;
my $newlist_line = "";

if ($flag_list) {
	$newlist_line = $oldlist{$list_num};
} else {
	$newlist_line = "MSA_ID";
}
my $count2 = 0;
foreach my $update_species (@update_species) {
	$count2++;
	unless ($newlist_line ~~ $update_species) {
		$newlist_line .= "\,$update_species\,related_species\,ident\,length";
		$newlist_line .= "\n" if $count2 == @update_species;
		$flag_new_species = 1;
	}
}
print NEWLIST $newlist_line;
foreach my $clean_input (sort {$a cmp $b} @clean_inputs_sort) {           ########### write best-hit protein sequence (with least E-value) to initial MSAs ###########
	my $fileExist = -e "${unaligned_dir}$clean_input";
	next if ($fileExist && !$flag_new_species);
	open (IN1, "<$clean_input_dir" . $clean_input);
	my $initial_MSA="";
	{									########## Read in whole file as one line ###########
		local $/=undef;
		$initial_MSA=<IN1>;
		close IN1;
	}
	open (OUT, ">$unaligned_dir" . $clean_input);
	print OUT $initial_MSA;
	$list_num++;
	$clean_input=~s/\.fa.+//;
	if ($flag_list) {
		$newlist_line = $oldlist{$list_num};
	} else {
		$newlist_line = $clean_input;
	}
	my $num_max;
	my $count = 0;
	foreach my $update_species (@update_species) {
		open (IN2, "<$blast_dir" . $update_species . "__" . $clean_input . "\.tab") or die "can not open: $!";;
		open (IN3, "<$blast_dir" . $clean_input . "__" . $update_species . "\.tab") or die "can not open: $!";;
		my %evalue_name;
		my %evalue_ident;
		my %evalue_length;
		my %evalue_species;
		my %flag_reciprocal_best_hit;
		my $tag = "";
		$num_max = 0;
		while (<IN2>) {
			my @ar = split /\t/, $_;
			$evalue_cutoff =~ s/.+e\-//;
			if ($ar[10]~~/\de\-(\d+)/ && $1 >= $evalue_cutoff) {  ############ select the subject with qualified blast-evalue (evalue <= $evalue_cutoff) ##############
				if ($ar[2]~~/^(\d+)/ && $1 >= $ident_cutoff) {    ############ select the subject with max blast-ident (ident <= $ident_cutoff) ##############
					my $num = $1;
					if ($num > $num_max) {
						$num_max = $num;
						$tag = $ar[0] . "\t" . $ar[1] . "\t" . $num_max;
						$evalue_name{$tag} = $ar[0];      ############ with least E-value ##############
						$evalue_species{$tag} = $ar[1];
						$evalue_ident{$tag} = int($ar[2]);
						$evalue_length{$tag} = int($ar[3]);
						$flag_reciprocal_best_hit{$tag} = 1;
					}
				}
			}
		}
		############ Identify reciprocal best-hit ##############
		while (<IN3>) {
			my $line = $_;
			my @ar = split /\t/, $_;
			if ($flag_reciprocal_best_hit{$tag}) {
				$tag2 = $tag;
				my @ar2 = split /\t/, $tag2;
				if ($line =~ /$ar2[1]\t$ar2[0]/) {
					$flag_reciprocal_best_hit{$tag} = 2;      ############ flag of reciprocal best-hit ##############
				}
			}
		}
		close IN2;
		close IN3;
		$count++;
		############ Add reciprocal best-hit protein sequence ##############
		if ($evalue_name{$tag} && $flag_reciprocal_best_hit{$tag} == 2) {
			unless (${$update_species}{$evalue_name{$tag}}) {
				print STDERR "ERROR: can not find protein: $evalue_name{$tag} in protein dateset: ${clean_new_prot_dir}${update_species} !\n" ;
				die;
			}
			print OUT ">$update_species\n" . ${$update_species}{$evalue_name{$tag}} . "\n";
			$newlist_line .= "\,$evalue_name{$tag}\,$evalue_species{$tag}\,$evalue_ident{$tag}\,$evalue_length{$tag}";
		} else {
			print OUT ">$update_species\n" . "-----------------------\n";
			$newlist_line .= "\,-\,-\,-\,-";
		}
		$newlist_line .= "\n" if $count == @update_species;	
	}
	close OUT;
	print NEWLIST $newlist_line;
}
close NEWLIST;
foreach my $update_species (@update_species) {
	%{$update_species} = ();               ############## empty the hash #############
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Aligning using MUSCLE...\n";
print STDERR "\n[$datestring] Aligning using MUSCLE...\n";
opendir UNALIGN_DIR, $unaligned_dir or die "can not open dir: $!";
my @unaligned_MSAs = grep /(\.fa$|\.fasta$)/i, readdir UNALIGN_DIR;
my @unaligned_MSAs_sort = sort {$a cmp $b} @unaligned_MSAs;
close UNALIGN_DIR;
if (!$opt_T && !$opt_M) {
	############ Show Progress ############
	$total = @unaligned_MSAs_sort;
	$count = 0;
	$percent2 = 0;
	#######################################
	$thread_id=1;
	foreach my $unaligned (@unaligned_MSAs_sort) {           ########### Align new protein with initial MSAs to get update MSAs ###########
		&show_progress($count,$total,$percent2);
		my $cmd = "muscle  -quiet  -in  ${unaligned_dir}$unaligned  -out  ${aligned_dir}$unaligned";
		my $modulus = $thread_id % $cpu;
		$cmd .= " &" if ($modulus && $thread_id < $total-2);    ########## enable multi-threads ###########
		$thread_id++;
		eval {&align_sh($cmd)};
		my $fileExist = -e "${aligned_dir}$unaligned";
		next if ($fileExist && !$flag_new_species);
		sleep (1);
		eval {&process_cmd($cmd)};
	}
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Concatenating update MSAs...\n";
print STDERR "\n[$datestring] Concatenating update MSAs...\n";
opendir ALIGN_DIR, $aligned_dir or die "can not open dir: $!";
my @aligned_MSAs = grep /(\.fa$|\.fasta$)/i, readdir ALIGN_DIR;
my @aligned_MSAs_sort = sort {$a cmp $b} @aligned_MSAs;
close ALIGN_DIR;
if (!$opt_T) {
	my %concatenated;
	foreach my $aligned (@aligned_MSAs_sort) {
		open (IN, "<$aligned_dir" . $aligned);
		my $seq_length;
		my %seq;
		my $seqs;
		{									########## Read in whole file as one line ###########
			local $/=undef;
			$seqs=<IN>;
			close IN;
		}
		my @ar = split /\>/, $seqs;
		foreach my $ar (@ar) {
			if ($ar ~~ /^(.+?)[\r\n](.+)[\r\n]/s) {
				my $name = $1;
				$seq{$name} = $2;
				$seq{$name} =~ s/\s//g;
				$concatenated{$name} .= $seq{$name};
				$seq_length = length($seq{$name});
			}
		}
		foreach my $initial_species (@initial_species) {
			if (!$seq{$initial_species} && $seq_length) {
				for (my $i=1; $i<=$seq_length; $i++) {
					$concatenated{$initial_species} .= "-";
				}
			}
		}
		foreach my $update_species (@update_species) {
			if (!$seq{$update_species} && $seq_length) {
				for (my $i=1; $i<=$seq_length; $i++) {
					$concatenated{$update_species} .= "-";
				}
			}
		}
	}
	my $fileExist = -e "${concatenate_dir}concatenated_MSA.fasta";
	if (!$fileExist or $flag_new_species) {
		open (OUT, ">$concatenate_dir" . "concatenated_MSA.fasta");
		foreach my $initial_species (@initial_species) {
			print OUT ">$initial_species\n$concatenated{$initial_species}\n" if $concatenated{$initial_species};
		}
		foreach my $update_species (@update_species) {
			print OUT ">$update_species\n$concatenated{$update_species}\n"  if $concatenated{$update_species};
		}
		close OUT;
	}
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}	
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Masking ambiguously aligned positions using BMGE...\n";
print STDERR "\n[$datestring] Masking ambiguously aligned positions using BMGE...\n";
if (!$opt_T) {
	############ Show Progress ############
	$total = @aligned_MSAs_sort;
	$count = 0;
	$percent2 = 0;
	#######################################
	$thread_id=1;
	foreach my $aligned (@aligned_MSAs_sort) {           ########### Masking ambiguously aligned positions using BMGE ###########
		&show_progress($count,$total,$percent2);
		my $cmd;
		if ($opt_S) {          ####### enable stringent mode #########
			$cmd = "java  -jar  ${BMGE_dir}BMGE.jar  -i  ${aligned_dir}$aligned  -t AA  -m BLOSUM62  -g 0.3  -b 5  -of  ${masked_dir}$aligned  -oh  ${masked_dir}${aligned}.html ";
		} else {
			$cmd = "java  -jar  ${BMGE_dir}BMGE.jar  -i  ${aligned_dir}$aligned  -t AA  -m BLOSUM30  -g 0.5  -b 5  -of  ${masked_dir}$aligned  -oh  ${masked_dir}${aligned}.html ";
		}
		my $modulus = $thread_id % $cpu;
		$cmd .= " &" if ($modulus && $thread_id < $total-1);    ########## enable multi-threads ###########
		$thread_id++;
		eval {&align_sh($cmd)};
		my $fileExist = -e "${masked_dir}$aligned";
		next if ($fileExist && !$flag_new_species);
		sleep (1);
		eval {&process_cmd($cmd)};
	}
	########### Masking ambiguously aligned positions using BMGE ###########
	my $cmd;
	if ($opt_S) {          ####### enable stringent mode #########
		$cmd = "java  -jar  ${BMGE_dir}BMGE.jar  -i  ${concatenate_dir}concatenated_MSA.fasta  -t AA  -m BLOSUM62  -g 0.3  -b 5  -of  ${concatenate_dir}concatenated_MSA_masked_stringent.fasta  -oh  ${concatenate_dir}concatenated_MSA_masked_stringent.fasta.html ";
	} else {
		$cmd = "java  -jar  ${BMGE_dir}BMGE.jar  -i  ${concatenate_dir}concatenated_MSA.fasta  -t AA  -m BLOSUM30  -g 0.5  -b 5  -of  ${concatenate_dir}concatenated_MSA_masked_relax.fasta  -oh  ${concatenate_dir}concatenated_MSA_masked_relax.fasta.html ";
	}
	eval {&align_sh($cmd)};
	sleep (1);
	eval {&process_cmd($cmd)};
	########################################################################
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n[$datestring] Phylogenetic tree constructing...\n";
print STDERR "\n[$datestring] Phylogenetic tree constructing...\n";
if ($opt_U) {
	print "\n[$datestring] Converting update MSAs (FASTA format) to NEXUS format with MrBayes command lines...\n";
	print STDERR "\n[$datestring] Converting update MSAs (FASTA format) to NEXUS format with MrBayes command lines...\n";
	opendir MASKED_DIR, $masked_dir or die "can not open dir: $!";
	my @fasta = grep /(\.fa$|\.fasta$)/i, readdir MASKED_DIR;
	my @fasta_sort = sort {$a cmp $b} @fasta;
	close MASKED_DIR;
	foreach my $fasta (@fasta_sort) {
		$nexus = $fasta;
		$nexus =~ s/(\.fa$|\.fasta$)/\.nex/;
		my $fileExist = -e "${masked_dir}$nexus";
		if (!$fileExist or $flag_new_species) {
			open (IN, "<$masked_dir" . $fasta);
			my %seq;
			my $seqs;
			{									########## Read in whole file as one line ###########
				local $/=undef;
				$seqs=<IN>;
				close IN;
			}
			my @ar = split /\>/, $seqs;
			my $seq_length;
			my $seq_num = 0;
			foreach my $ar (@ar) {
				if ($ar ~~ /^(.+?)[\r\n](.+)[\r\n]/s) {
					my $name = $1;
					$seq{$name} = $2;
					$seq{$name} =~ s/\s//g;
					$seq_length = length($seq{$name});
					$seq_num++;
				}
			}
			if ($seq_length) {
				open (OUT, ">${masked_dir}$nexus");
				print OUT "#NEXUS\nbegin data;\n\tdimensions ntax=$seq_num nchar=$seq_length;\n\tformat datatype=protein missing=? gap=-;\nmatrix\n";
				
				my $max_name = 0;
				foreach my $initial_species (@initial_species) {
					$max_name = length ($initial_species) if $max_name<length ($initial_species);
				}
				foreach $update_species (@update_species) {
					$max_name = length ($update_species) if $max_name<length ($update_species);
				}
				my $width = ($max_name + 1) * (-1);
				foreach $initial_species (@initial_species) {
					if ($seq{$initial_species}) {
						printf OUT "%${width}s", $initial_species;
						print OUT "$seq{$initial_species}\n" ;
					}
				}
				foreach $update_species (@update_species) {
					if ($seq{$update_species}) {
						printf OUT "%${width}s", $update_species;
						print OUT "$seq{$update_species}\n" ;
					}
				}
			my $burnin = $generation / $freq * 0.1;
			print OUT ";\nend;\nbegin mrbayes;\nprset aamodelpr=mixed;\nmcmcp ngen=$generation samplefreq=$freq nchains=4 savebrlens=yes;\nmcmc;\nsump burnin=$burnin;\nsumt burnin=$burnin;\nend;\n";
			close OUT;
			}
		}
		$fileExist = -e "${BItree_aligned_dir}$nexus";
		if (!$fileExist or $flag_new_species) {
			my $cmd = "cp ${masked_dir}$nexus ${BItree_aligned_dir}$nexus";
			eval {&process_cmd($cmd)};
		}
	}
	########################################################################
	$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
	print "\n[$datestring] Converting concatenated MSA (FASTA format) to NEXUS format with MrBayes command lines...\n";
	print STDERR "\n[$datestring] Converting concatenated MSA (FASTA format) to NEXUS format with MrBayes command lines...\n";
	opendir CONCATENATE_DIR, $concatenate_dir or die "can not open dir: $!";
	@fasta = "";
	@fasta = grep /(\.fa$|\.fasta$)/i, readdir CONCATENATE_DIR;
	@fasta_sort = sort {$a cmp $b} @fasta;
	close CONCATENATE_DIR;
	foreach my $fasta (@fasta_sort) {
		$nexus = $fasta;
		$nexus =~ s/(\.fa$|\.fasta$)/\.nex/;
		my $fileExist = -e "${concatenate_dir}$nexus";
		if (!$fileExist or $flag_new_species) {
			open (IN, "<$concatenate_dir" . $fasta);
			my %seq;
			my $seqs;
			{									########## Read in whole file as one line ###########
				local $/=undef;
				$seqs=<IN>;
				close IN;
			}
			my @ar = split /\>/, $seqs;
			my $seq_length;
			my $seq_num = 0;
			foreach my $ar (@ar) {
				if ($ar ~~ /^(.+?)[\r\n](.+)[\r\n]/s) {
					my $name = $1;
					$seq{$name} = $2;
					$seq{$name} =~ s/\s//g;
					$seq_length = length($seq{$name});
					$seq_num++;
				}
			}
			open (OUT, ">$concatenate_dir" . $nexus);
			print OUT "#NEXUS\nbegin data;\n\tdimensions ntax=$seq_num nchar=$seq_length;\n\tformat datatype=protein missing=? gap=-;\nmatrix\n";
			my $max_name = 0;
			foreach my $initial_species (@initial_species) {
				$max_name = length ($initial_species) if $max_name<length ($initial_species);
			}
			foreach $update_species (@update_species) {
				$max_name = length ($update_species) if $max_name<length ($update_species);
			}
			my $width = ($max_name + 1) * (-1);
			foreach $initial_species (@initial_species) {
				if ($seq{$initial_species}) {
					printf OUT "%${width}s", $initial_species;
					print OUT "$seq{$initial_species}\n";
				}
			}
			foreach $update_species (@update_species) {
				if ($seq{$update_species}) {
					printf OUT "%${width}s", $update_species;
					print OUT "$seq{$update_species}\n";
				}
			}
			my $burnin = $generation /$freq * 0.1;
			print OUT ";\nend;\nbegin mrbayes;\nprset aamodelpr=mixed;\nmcmcp ngen=$generation samplefreq=$freq nchains=4 savebrlens=yes;\nmcmc;\nsump burnin=$burnin;\nsumt burnin=$burnin;\nend;\n";
			close OUT;
		}
		{
			my $fileExist = -e "${BItree_concatenate_dir}$nexus";
			if (!$fileExist or $flag_new_species) {
				my $cmd = "cp ${concatenate_dir}$nexus ${BItree_concatenate_dir}$nexus";
				eval {&process_cmd($cmd)};
			}
		}
	}
	########################################################################
	$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
	print "\n[$datestring] Constructing BI trees according to update MSAs (NEXUS format) using MrBayes...\n";
	print STDERR "\n[$datestring] Constructing BI trees according to update MSAs (NEXUS format) using MrBayes...\n";
	opendir NEXUS_DIR, $BItree_aligned_dir or die "can not open dir: $!";
	my @nexus = grep /\.nex$/i, readdir NEXUS_DIR;
	my @nexus_sort = sort {$a cmp $b} @nexus;
	close NEXUS_DIR;
	opendir NEXUS_DIR, $BItree_aligned_dir or die "can not open dir: $!";
	my @trees = grep /\.nex\.con\.tre$/i, readdir NEXUS_DIR;
	close NEXUS_DIR;
	opendir NEXUS_DIR, $BItree_aligned_dir or die "can not open dir: $!";
	my @runt = grep /run1\.t$/i, readdir NEXUS_DIR;
	close NEXUS_DIR;
	############ Show Progress ############
	$total = @nexus_sort;
	$count = 0;
	$percent2 = 0;
	#######################################
	{
		my $fileExist = -e "${BItree_aligned_dir}bucky.concordance.tre";
		if ($fileExist && $flag_new_species) {
			my $cmd2;
			if ($#trees != $#runt) {
				$cmd2 = "cd ${BItree_aligned_dir}\n rm *.nex.*\n rm bucky*";
			} else {
				$cmd2 = "cd ${BItree_aligned_dir}\n rm bucky*";
			}
			# die "$#trees \t $#runt\n\n";
			eval {&process_cmd($cmd2)};
		}
	}
	$thread_id=1;
	foreach my $nexus (@nexus_sort) {
		&show_progress($count,$total,$percent2);
		my $cmd = "cd ${BItree_aligned_dir}\n mb -i $nexus";
		my $modulus = $thread_id % $cpu;
		$cmd .= " &";    ########## enable multi-threads ###########
		$thread_id++;
		eval {&BItree_sh($cmd)};
		my $fileExist = -e "${BItree_aligned_dir}$nexus.con.tre";
		next if ($fileExist && !$flag_new_species);
		sleep (1);
		eval {&process_cmd($cmd)};
		if (!$modulus or $thread_id >= $total - 1) {
			while (1) {
				my $fileExist = -e "${BItree_aligned_dir}${nexus}.con.tre";
				last if ($fileExist);
				sleep (1);
			}
		}
	}
	opendir NEXUS_DIR, $BItree_aligned_dir or die "can not open dir: $!";
	my @mcmc = grep /\.nex\.mcmc$/i, readdir NEXUS_DIR;
	my @mcmc_sort = sort {$a cmp $b} @mcmc;
	close NEXUS_DIR;
	if ($opt_S) {
		open (OUT, ">$log_dir" . "FinalAvgStdDevs_coalescent_BI_trees_stringent_g${generation}_f${freq}.log" ) or die "can not open: $!";
	} else {
		open (OUT, ">$log_dir" . "FinalAvgStdDevs_coalescent_BI_trees_relax_g${generation}_f${freq}.log" ) or die "can not open: $!";
	}
	print OUT "Tree\tFinalAvgStdDev(Average standard deviation of split frequencies)\tGeneration:$generation\n";
	foreach my $mcmc (@mcmc_sort) {
		open (IN, "<$BItree_aligned_dir" . $mcmc) or die "can not open: $!";
		my $content;
		{									########## Read in whole file as one line ###########
			local $/=undef;
			$content=<IN>;
			close IN;
		}
		if ($content =~ /\t(\d+\.\d+)[\r\n]*$/) {
			my $final_FinalAvgStdDev = $1;
			$mcmc =~ s/\.nex\.mcmc//;
			print OUT $mcmc . "\t" . $final_FinalAvgStdDev . "\n";
		}
	}
	close OUT;
	########################################################################
	$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
	print "\n[$datestring] Constructing coalescent (concordant) BI tree according to update MSAs (NEXUS format) using BUCKy...\n";
	print STDERR "\n[$datestring] Constructing coalescent (concordant) BI tree according to update MSAs (NEXUS format) using BUCKy...\n";
	print "\n[$datestring] Preparing inputs for BUCKy...\n";
	print STDERR "\n[$datestring] Preparing inputs for BUCKy...\n";
	############ Show Progress ############
	$total = @nexus_sort;
	$count = 0;
	$percent2 = 0;
	#######################################
	$thread_id=1;
	foreach my $nexus (@nexus_sort) {
		&show_progress($count,$total,$percent2);
		my $fileExist = -e "${BItree_aligned_dir}${nexus}.run1.t";
		if ($fileExist) {
			my $burnin = int(($generation/$freq)*0.1);
			my $cmd = "cd ${BItree_aligned_dir}\n mbsum  -n  $burnin  -o  ${nexus}.in  ${nexus}.run?.t";
			my $modulus = $thread_id % $cpu;
			$cmd .= " &"  if ($modulus && $thread_id < $total-1);    ########## enable multi-threads ###########
			$thread_id++;
			eval {&BItree_sh($cmd)};
			my $fileExist2 = -e "${BItree_aligned_dir}${nexus}.in";
			next if ($fileExist2 && !$flag_new_species);
			sleep (1);
			eval {&process_cmd($cmd)};
		}
	}
	$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
	print "\n[$datestring] Calculating coalescent (concordant) BI tree using BUCKy...\n";
	print STDERR "\n[$datestring] Calculating coalescent (concordant) BI tree using BUCKy...\n";
	{
		my $fileExist = -e "${BItree_aligned_dir}bucky.concordance";
		if (!$fileExist or $flag_new_species) {
			my $cmd = "";
			if (defined $opt_l) {
				$cmd = "cd ${BItree_aligned_dir}\n bucky -o bucky -n $generation -sg -p $opt_l *.in";   ############## use 4 chains: bucky -c 4 -n $generation *.in #############
			} else {
				$cmd = "cd ${BItree_aligned_dir}\n bucky -o bucky -n $generation *.in";   ############## use 4 chains: bucky -c 4 -n $generation *.in #############
			}		
			eval {&BItree_sh($cmd)};
			eval {&process_cmd($cmd)};
		}
	}
	########################################################################
	$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
	print "\n[$datestring] Outputing coalescent (concordant) BI tree built by BUCKy...\n";
	print STDERR "\n[$datestring] Outputing coalescent (concordant) BI tree built by BUCKy...\n";
	open (IN, "<$BItree_aligned_dir" . "bucky.concordance") or die "can not open: $!";
	my @species_name;
	foreach (<IN>) {
		if (/^\s+(\d+)\s(.+?)(,|;)$/) {
			$species_name[$1] = $2;
		}
	}
	open (IN, "<$BItree_aligned_dir" . "bucky.concordance") or die "can not open: $!";
	my $lines;
	{									########## Read in whole file as one line ###########
		local $/=undef;
		$lines=<IN>;
		close IN;
	}
	my $coalescent_tree;
	open (OUT, ">$BItree_aligned_dir" . "bucky.concordance.tre");
	if ($lines =~ /Primary Concordance Tree with Sample Concordance Factors:\n(.+?\;\n)\n/) {
		$coalescent_tree = $1;
		for (my $i = 0; $i < @species_name; $i++) {
			my $species_id = $i + 1;
			$coalescent_tree =~ s/\b$species_id\:/$species_name[$species_id]\:/;
		}
	}
	$coalescent_tree =~ s/alextama:/Alexandrium_tamarense_db:/;
	$coalescent_tree =~ s/anophryoides:/Anophryoides_haemophila_db:/;
	$coalescent_tree =~ s/Aristerosto:/Aristerostoma_sp._db:/;
	$coalescent_tree =~ s/Babesia:/Babesia_bovis_db:/;
	$coalescent_tree =~ s/Condylosto:/Condylostoma_magnum_db:/;
	$coalescent_tree =~ s/crypparv:/Cryptosporidium_parvum_db:/;
	$coalescent_tree =~ s/Crypthomi:/Cryptosporidium_hominis_db:/;
	$coalescent_tree =~ s/Euplofoca:/Euplotes_focardii_db:/;
	$coalescent_tree =~ s/Euplohar:/Euplotes_harpa_db:/;
	$coalescent_tree =~ s/Favella:/Schmidingerella_arcuata_db:/;
	$coalescent_tree =~ s/Ichth:/Ichthyophthirius_db:/;
	$coalescent_tree =~ s/karebrev:/Karenia_brevis_db:/;
	$coalescent_tree =~ s/Litonotus:/Litonotus_sp._db:/;
	$coalescent_tree =~ s/miamiensis:/Miamiensis_avidus_db:/;
	$coalescent_tree =~ s/Neospora:/Neospora_caninum_db:/;
	$coalescent_tree =~ s/Nyctothov:/Nyctotherus_ovalis_db:/;
	$coalescent_tree =~ s/opisthonecta:/Opisthonecta_henneguyi_db:/;
	$coalescent_tree =~ s/oxyrmari:/Oxyrrhis_marina_db:/;
	$coalescent_tree =~ s/oxyttrif:/Oxytricha_trifallax_db:/;
	$coalescent_tree =~ s/paratetr:/Paramecium_tetraurelia_db:/;
	$coalescent_tree =~ s/perkmari:/Perkinsus_marinus_db:/;
	$coalescent_tree =~ s/plaschab:/Plasmodium_chabaudi_db:/;
	$coalescent_tree =~ s/plasfalc:/Plasmodium_falciparum_db:/;
	$coalescent_tree =~ s/platyophry:/Platyophrya_macrostoma_db:/;
	$coalescent_tree =~ s/protocruzi:/Protocruzia_adherens_db:/;
	$coalescent_tree =~ s/pseudoke:/Pseudokeronopsis_riccii_db:/;
	$coalescent_tree =~ s/sarcneur:/Sarcocystis_neurona_db:/;
	$coalescent_tree =~ s/scyphidia:/Scyphidia_ubiquita_db:/;
	$coalescent_tree =~ s/stromacum:/Strombidinopsis_acuminatum_db:/;
	$coalescent_tree =~ s/Strombinc:/Strombidium_inclinatum_db:/;
	$coalescent_tree =~ s/tetrther:/Tetrahymena_thermophila_db:/;
	$coalescent_tree =~ s/theiannu:/Theileria_annulata_db:/;
	$coalescent_tree =~ s/toxogond:/Toxoplasma_gondii_db:/;
	$coalescent_tree =~ s/trichodina:/Trichodina_pediculus_db:/;
	$coalescent_tree =~ s/urceolaria:/Urceolaria_korschelti_db:/;
	$coalescent_tree =~ s/uronema:/Uronema_sp._db:/;
	$coalescent_tree =~ s/vorticella:/Vorticella_microstoma_db:/;
	print OUT "$coalescent_tree";
	close OUT;
	########################################################################
} else {
	print "\n...Skipped!\n";
	print STDERR "\n...Skipped!\n";
}
########################################################################
$datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;
print "\n##########################################\n##########################################\n[$datestring] Job finished!\n##########################################\n##########################################\n\n";
print STDERR "\n##########################################\n##########################################\n[$datestring] Job finished!\n##########################################\n##########################################\n\n";
}
########################################################################
########################################################################
sub process_cmd {
	my ($cmd) = @_;
	print "CMD: $cmd\n";
	my $start_time = time();
	my $ret = system($cmd);
	my $end_time = time();
	if ($ret) {
		die "Error, cmd: $cmd died with ret $ret";
	}
	print "CMD finished (" . ($end_time - $start_time) . " seconds)\n\n\n";
	return;
}
########################################################################
sub int_handler {
	die "Interrupted from keyboard, exiting...\n\n";
}
########################################################################
sub blast_sh {
	open (SH1, ">>$sh_dir" . "01_blast.sh") or die "can not open: $!";
	my ($cmd) = @_;
	print SH1 "$cmd\n";
	close SH1;
	return;
}
########################################################################
sub align_sh {
	open (SH2, ">>$sh_dir" . "02_align.sh") or die "can not open: $!";
	my ($cmd) = @_;
	print SH2 "$cmd\n";
	close SH2;
	return;
}
########################################################################
sub BItree_sh {
	open (SH3, ">>$sh_dir" . "03_BItree.sh") or die "can not open: $!";
	my ($cmd) = @_;
	print SH3 "$cmd\n";
	close SH3;
	return;
}
################ Show Progress #########################################
sub show_progress {
	$_[0]++;
	my $percent=int(100*$_[0]/$_[1]);
	if ($_[2]<$percent){
		$_[2]=$percent;
		print STDERR "$_[2]\%\n";
		print "$_[2]\%\n";
	}
}
########################################################################
