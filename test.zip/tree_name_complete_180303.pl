#!/usr/bin/perl -w

print STDERR "\nComplete the species names in the tree...\n";

open (IN, "<$ARGV[0]") or die "can not open: $!";
open (OUT, ">$ARGV[1]");

my $tree;
{									########## Read in whole file as one line ###########
	local $/=undef;
	$tree=<IN>;
	close IN;
}

##### For BUCKy tree from original MSAs #####
$tree =~ s/alextama(\W)/Alexandrium_tamarense_db$1/gi;
$tree =~ s/anophryoides(\W)/Anophryoides_haemophila_db$1/gi;
$tree =~ s/Aristerosto(\W)/Aristerostoma_sp._db$1/gi;
$tree =~ s/Babesia(\W)/Babesia_bovis_db$1/gi;
$tree =~ s/Condylosto(\W)/Condylostoma_magnum_db$1/gi;
$tree =~ s/crypparv(\W)/Cryptosporidium_parvum_db$1/gi;
$tree =~ s/Crypthomi(\W)/Cryptosporidium_hominis_db$1/gi;
$tree =~ s/Euplofoca(\W)/Euplotes_focardii_db$1/gi;
$tree =~ s/Euplohar(\W)/Euplotes_harpa_db$1/gi;
$tree =~ s/Favella(\W)/Schmidingerella_arcuata_db$1/gi;
$tree =~ s/Ichth(\W)/Ichthyophthirius_multifiliis_db$1/gi;
$tree =~ s/karebrev(\W)/Karenia_brevis_db$1/gi;
$tree =~ s/Litonotus(\W)/Litonotus_sp._db$1/gi;
$tree =~ s/miamiensis(\W)/Miamiensis_avidus_db$1/gi;
$tree =~ s/Neospora(\W)/Neospora_caninum_db$1/gi;
$tree =~ s/Nyctothov(\W)/Nyctotherus_ovalis_db$1/gi;
$tree =~ s/opisthonecta(\W)/Opisthonecta_henneguyi_db$1/gi;
$tree =~ s/oxyrmari(\W)/Oxyrrhis_marina_db$1/gi;
$tree =~ s/oxyttrif(\W)/Oxytricha_trifallax_db$1/gi;
$tree =~ s/paratetr(\W)/Paramecium_tetraurelia_db$1/gi;
$tree =~ s/perkmari(\W)/Perkinsus_marinus_db$1/gi;
$tree =~ s/plaschab(\W)/Plasmodium_chabaudi_db$1/gi;
$tree =~ s/plasfalc(\W)/Plasmodium_falciparum_db$1/gi;
$tree =~ s/platyophry(\W)/Platyophrya_macrostoma_db$1/gi;
$tree =~ s/protocruzi(\W)/Protocruzia_adherens_db$1/gi;
$tree =~ s/pseudoke(\W)/Pseudokeronopsis_riccii_db$1/gi;
$tree =~ s/sarcneur(\W)/Sarcocystis_neurona_db$1/gi;
$tree =~ s/scyphidia(\W)/Scyphidia_ubiquita_db$1/gi;
$tree =~ s/stromacum(\W)/Strombidinopsis_acuminatum_db$1/gi;
$tree =~ s/Strombinc(\W)/Strombidium_inclinatum_db$1/gi;
$tree =~ s/tetrther(\W)/Tetrahymena_thermophila_db$1/gi;
$tree =~ s/theiannu(\W)/Theileria_annulata_db$1/gi;
$tree =~ s/toxogond(\W)/Toxoplasma_gondii_db$1/gi;
$tree =~ s/trichodina(\W)/Trichodina_pediculus_db$1/gi;
$tree =~ s/urceolaria(\W)/Urceolaria_korschelti_db$1/gi;
$tree =~ s/uronema(\W)/Uronema_sp._db$1/gi;
$tree =~ s/vorticella(\W)/Vorticella_microstoma_db$1/gi;

##### For PhyloBayes tree from Phylip format file #####
$tree =~ s/anophryoid(\W)/Anophryoides_haemophila_db$1/gi;
$tree =~ s/Aristerost(\W)/Aristerostoma_sp._db$1/gi;
$tree =~ s/opisthonec(\W)/Opisthonecta_henneguyi_db$1/gi;

$tree =~ s/Anteholost(\W)/Anteholosticha_monilata$1/gi;
$tree =~ s/Aristero_2(\W)/Aristerostoma_sp$1/gi;
$tree =~ s/Blepharism(\W)/Blepharisma_japonicum$1/gi;
$tree =~ s/Climacosto(\W)/Climacostomum_virens$1/gi;
$tree =~ s/Deviata_sp(\W)/Deviata_sp$1/gi;
$tree =~ s/Diophrys_s(\W)/Diophrys_scutum$1/gi;
$tree =~ s/Euplotes_c(\W)/Euplotes_crassus$1/gi;
$tree =~ s/Euplotes_f(\W)/Euplotes_focardii$1/gi;
$tree =~ s/Fabrea_sal(\W)/Fabrea_salina$1/gi;
$tree =~ s/Favella_ta(\W)/Schmidingerella_taraikaensis$1/gi;
$tree =~ s/Pseudoke_B(\W)/Pseudokeronopsis_sp_Brazil$1/gi;
$tree =~ s/Pseudoke_O(\W)/Pseudokeronopsis_sp_OXSARD2$1/gi;
$tree =~ s/Strombidiu(\W)/Strombidium_sulcatum_genome$1/gi;


print OUT "$tree";
close OUT;

print STDERR "\nJob Finished!\n";
