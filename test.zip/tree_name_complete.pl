#!/usr:/bin/perl -w

print STDERR "\nComplete the species names in the tree...\n";

open (IN, "<$ARGV[0]") or die "can not open: $!";
open (OUT, ">$ARGV[0]" . "_fullname.tre");

my $tree;
{									########## Read in whole file as one line ###########
	local $/=undef;
	$tree=<IN>;
	close IN;
}

##### For BUCKy tree from original MSAs #####
$tree =~ s/alextama:/Alexandrium_tamarense_db:/g;
$tree =~ s/anophryoides:/Anophryoides_haemophila_db:/g;
$tree =~ s/Aristerosto:/Aristerostoma_sp._db:/g;
$tree =~ s/Babesia:/Babesia_bovis_db:/g;
$tree =~ s/Condylosto:/Condylostoma_magnum_db:/g;
$tree =~ s/crypparv:/Cryptosporidium_parvum_db:/g;
$tree =~ s/Crypthomi:/Cryptosporidium_hominis_db:/g;
$tree =~ s/Euplofoca:/Euplotes_focardii_db:/g;
$tree =~ s/Euplohar:/Euplotes_harpa_db:/g;
$tree =~ s/Favella:/Schmidingerella_arcuata_db:/g;
$tree =~ s/Ichth:/Ichthyophthirius_multifiliis_db:/g;
$tree =~ s/karebrev:/Karenia_brevis_db:/g;
$tree =~ s/Litonotus:/Litonotus_sp._db:/g;
$tree =~ s/miamiensis:/Miamiensis_avidus_db:/g;
$tree =~ s/Neospora:/Neospora_caninum_db:/g;
$tree =~ s/Nyctothov:/Nyctotherus_ovalis_db:/g;
$tree =~ s/opisthonecta:/Opisthonecta_henneguyi_db:/g;
$tree =~ s/oxyrmari:/Oxyrrhis_marina_db:/g;
$tree =~ s/oxyttrif:/Oxytricha_trifallax_db:/g;
$tree =~ s/paratetr:/Paramecium_tetraurelia_db:/g;
$tree =~ s/perkmari:/Perkinsus_marinus_db:/g;
$tree =~ s/plaschab:/Plasmodium_chabaudi_db:/g;
$tree =~ s/plasfalc:/Plasmodium_falciparum_db:/g;
$tree =~ s/platyophry:/Platyophrya_macrostoma_db:/g;
$tree =~ s/protocruzi:/Protocruzia_adherens_db:/g;
$tree =~ s/pseudoke:/Pseudokeronopsis_riccii_db:/g;
$tree =~ s/sarcneur:/Sarcocystis_neurona_db:/g;
$tree =~ s/scyphidia:/Scyphidia_ubiquita_db:/g;
$tree =~ s/stromacum:/Strombidinopsis_acuminatum_db:/g;
$tree =~ s/Strombinc:/Strombidium_inclinatum_db:/g;
$tree =~ s/tetrther:/Tetrahymena_thermophila_db:/g;
$tree =~ s/theiannu:/Theileria_annulata_db:/g;
$tree =~ s/toxogond:/Toxoplasma_gondii_db:/g;
$tree =~ s/trichodina:/Trichodina_pediculus_db:/g;
$tree =~ s/urceolaria:/Urceolaria_korschelti_db:/g;
$tree =~ s/uronema:/Uronema_sp._db:/g;
$tree =~ s/vorticella:/Vorticella_microstoma_db:/g;

##### For PhyloBayes tree from Phylip format file #####
$tree =~ s/anophryoid:/Anophryoides_haemophila_db:/g;
$tree =~ s/Aristerost:/Aristerostoma_sp._db:/g;
$tree =~ s/opisthonec:/Opisthonecta_henneguyi_db:/g;

$tree =~ s/Anteholost:/Anteholosticha_monilata:/g;
$tree =~ s/Aristero_2:/Aristerostoma_sp:/g;
$tree =~ s/Blepharism:/Blepharisma_japonicum:/g;
$tree =~ s/Climacosto:/Climacostomum_virens:/g;
$tree =~ s/Deviata_sp:/Deviata_sp:/g;
$tree =~ s/Diophrys_s:/Diophrys_scutum:/g;
$tree =~ s/Euplotes_c:/Euplotes_crassus:/g;
$tree =~ s/Euplotes_f:/Euplotes_focardii:/g;
$tree =~ s/Fabrea_sal:/Fabrea_salina:/g;
$tree =~ s/Favella_ta:/Schmidingerella_taraikaensis:/g;
$tree =~ s/Pseudoke_B:/Pseudokeronopsis_sp_Brazil:/g;
$tree =~ s/Pseudoke_O:/Pseudokeronopsis_sp_OXSARD2:/g;
$tree =~ s/Strombidiu:/Strombidium_sulcatum_genome:/g;


print OUT "$tree";
close OUT;

print STDERR "\nJob Finished!\n";
